import React from 'react'
import './searchproduct.css'
const SearchProduct=()=> {
  return (
    <>
    <section className='search-products '>

<div className='search-function'>
<div className='container-fluid'>

<input/>

</div>

</div>
    </section>
    
    </>
  )
}

export default SearchProduct